from __future__ import annotations

import random
from pathlib import Path
from typing import Callable

import numpy as np
import torch
from PIL import Image
from scipy.io import loadmat
from torch.utils.data import Dataset
from torchvision.transforms import functional as TF
from torchvision.transforms.functional import InterpolationMode


def list_pairs(root: str | Path) -> list[tuple[Path, Path]]:
    root = Path(root)
    image_dir = root / "image"
    gt_dir = root / "groundTruth"
    images = sorted(image_dir.glob("*.jpg"))
    pairs = []
    for img in images:
        mat = gt_dir / f"{img.stem}.mat"
        if mat.exists():
            pairs.append((img, mat))
    if not pairs:
        raise FileNotFoundError(f"No image/.mat pairs found under {root}")
    return pairs


def split_pairs(pairs, train_ratio=0.70, val_ratio=0.15, seed=42):
    idx = list(range(len(pairs)))
    rng = random.Random(seed)
    rng.shuffle(idx)
    n_train = int(len(idx) * train_ratio)
    n_val = int(len(idx) * val_ratio)
    train = [pairs[i] for i in idx[:n_train]]
    val = [pairs[i] for i in idx[n_train:n_train+n_val]]
    test = [pairs[i] for i in idx[n_train+n_val:]]
    return train, val, test


def load_cfd_mask(mat_path: str | Path) -> Image.Image:
    m = loadmat(mat_path)
    gt = m["groundTruth"][0, 0]
    boundaries = gt["Boundaries"]
    while isinstance(boundaries, np.ndarray) and boundaries.dtype == object:
        boundaries = boundaries.flat[0]
    mask = (np.asarray(boundaries) > 0).astype(np.uint8) * 255
    return Image.fromarray(mask, mode="L")


def pil_to_tensor(img: Image.Image) -> torch.Tensor:
    return TF.to_tensor(img)


def resize_image(img: Image.Image, size_hw: tuple[int, int], bicubic=True) -> Image.Image:
    interpolation = InterpolationMode.BICUBIC if bicubic else InterpolationMode.NEAREST
    return TF.resize(img, list(size_hw), interpolation=interpolation, antialias=True)


def augment_pair(img: Image.Image, mask: Image.Image | None = None):
    if random.random() < 0.5:
        img = TF.hflip(img)
        if mask is not None:
            mask = TF.hflip(mask)
    if random.random() < 0.5:
        img = TF.vflip(img)
        if mask is not None:
            mask = TF.vflip(mask)
    k = random.randint(0, 3)
    if k:
        angle = 90 * k
        img = TF.rotate(img, angle, interpolation=InterpolationMode.BILINEAR)
        if mask is not None:
            mask = TF.rotate(mask, angle, interpolation=InterpolationMode.NEAREST)
    return img, mask


class SRPatchDataset(Dataset):
    def __init__(self, pairs, scale=4, hr_patch_size=96, patches_per_image=8, augment=True):
        self.pairs = pairs
        self.scale = scale
        self.hr_patch_size = hr_patch_size
        self.patches_per_image = patches_per_image
        self.augment = augment
        if hr_patch_size % scale != 0:
            raise ValueError("hr_patch_size must be divisible by scale")

    def __len__(self):
        return len(self.pairs) * self.patches_per_image

    def __getitem__(self, index):
        img_path, _ = self.pairs[index // self.patches_per_image]
        hr = Image.open(img_path).convert("RGB")
        w, h = hr.size
        p = self.hr_patch_size
        if w < p or h < p:
            scale_up = max(p / w, p / h)
            hr = hr.resize((int(w * scale_up) + 1, int(h * scale_up) + 1), Image.Resampling.BICUBIC)
            w, h = hr.size
        left = random.randint(0, w - p)
        top = random.randint(0, h - p)
        hr = hr.crop((left, top, left + p, top + p))
        if self.augment:
            hr, _ = augment_pair(hr)
        lr_size = p // self.scale
        lr = hr.resize((lr_size, lr_size), Image.Resampling.BICUBIC)
        bic = lr.resize((p, p), Image.Resampling.BICUBIC)
        return pil_to_tensor(lr), pil_to_tensor(bic), pil_to_tensor(hr)


class SRFullDataset(Dataset):
    def __init__(self, pairs, hr_size=(128, 128), scale=4):
        self.pairs = pairs
        self.hr_size = hr_size
        self.scale = scale

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, index):
        img_path, _ = self.pairs[index]
        hr = Image.open(img_path).convert("RGB")
        hr = resize_image(hr, self.hr_size, bicubic=True)
        lr = hr.resize((self.hr_size[1] // self.scale, self.hr_size[0] // self.scale), Image.Resampling.BICUBIC)
        bic = lr.resize((self.hr_size[1], self.hr_size[0]), Image.Resampling.BICUBIC)
        return pil_to_tensor(lr), pil_to_tensor(bic), pil_to_tensor(hr), img_path.stem


class SegmentationDataset(Dataset):
    def __init__(self, pairs, size=(128, 128), augment=False, image_transform: Callable | None = None):
        self.pairs = pairs
        self.size = size
        self.augment = augment
        self.image_transform = image_transform

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, index):
        img_path, mat_path = self.pairs[index]
        img = Image.open(img_path).convert("RGB")
        mask = load_cfd_mask(mat_path)
        img = resize_image(img, self.size, bicubic=True)
        mask = resize_image(mask, self.size, bicubic=False)
        if self.augment:
            img, mask = augment_pair(img, mask)
        x = pil_to_tensor(img)
        if self.image_transform is not None:
            x = self.image_transform(x, img_path.stem)
        y = (pil_to_tensor(mask) > 0.5).float()
        return x, y, img_path.stem
