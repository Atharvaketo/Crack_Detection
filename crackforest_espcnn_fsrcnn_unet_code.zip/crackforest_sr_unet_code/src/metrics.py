from __future__ import annotations

import numpy as np
import torch
from skimage.metrics import peak_signal_noise_ratio, structural_similarity


def sr_metrics(pred: torch.Tensor, target: torch.Tensor):
    p = pred.detach().cpu().permute(1, 2, 0).numpy()
    t = target.detach().cpu().permute(1, 2, 0).numpy()
    psnr = peak_signal_noise_ratio(t, p, data_range=1.0)
    ssim = structural_similarity(t, p, channel_axis=2, data_range=1.0)
    return float(psnr), float(ssim)


def segmentation_counts(logits, targets, threshold=0.5):
    pred = (torch.sigmoid(logits) >= threshold)
    true = targets >= 0.5
    tp = (pred & true).sum().item()
    fp = (pred & ~true).sum().item()
    fn = (~pred & true).sum().item()
    tn = (~pred & ~true).sum().item()
    return tp, fp, fn, tn


def metrics_from_counts(tp, fp, fn, tn, eps=1e-8):
    precision = tp / (tp + fp + eps)
    recall = tp / (tp + fn + eps)
    dice = 2 * tp / (2 * tp + fp + fn + eps)
    iou = tp / (tp + fp + fn + eps)
    accuracy = (tp + tn) / (tp + tn + fp + fn + eps)
    return dict(precision=precision, recall=recall, dice=dice, iou=iou, accuracy=accuracy)
