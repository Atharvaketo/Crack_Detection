from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class ESPCNNResidual(nn.Module):
    def __init__(self, scale=4, channels=3):
        super().__init__()
        self.scale = scale
        self.body = nn.Sequential(
            nn.Conv2d(channels, 64, 5, padding=2), nn.ReLU(inplace=True),
            nn.Conv2d(64, 64, 3, padding=1), nn.ReLU(inplace=True),
            nn.Conv2d(64, 32, 3, padding=1), nn.ReLU(inplace=True),
            nn.Conv2d(32, channels * scale * scale, 3, padding=1),
            nn.PixelShuffle(scale),
        )

    def forward(self, lr, bicubic=None):
        if bicubic is None:
            bicubic = F.interpolate(lr, scale_factor=self.scale, mode="bicubic", align_corners=False)
        residual = self.body(lr)
        return torch.clamp(bicubic + residual, 0.0, 1.0)


class FSRCNNResidual(nn.Module):
    def __init__(self, scale=4, channels=3, d=56, s=12, m=4):
        super().__init__()
        self.scale = scale
        layers = [
            nn.Conv2d(channels, d, 5, padding=2), nn.PReLU(d),
            nn.Conv2d(d, s, 1), nn.PReLU(s),
        ]
        for _ in range(m):
            layers += [nn.Conv2d(s, s, 3, padding=1), nn.PReLU(s)]
        layers += [
            nn.Conv2d(s, d, 1), nn.PReLU(d),
            nn.ConvTranspose2d(d, channels, 9, stride=scale, padding=4, output_padding=scale-1),
        ]
        self.body = nn.Sequential(*layers)

    def forward(self, lr, bicubic=None):
        if bicubic is None:
            bicubic = F.interpolate(lr, scale_factor=self.scale, mode="bicubic", align_corners=False)
        residual = self.body(lr)
        if residual.shape[-2:] != bicubic.shape[-2:]:
            residual = F.interpolate(residual, size=bicubic.shape[-2:], mode="bilinear", align_corners=False)
        return torch.clamp(bicubic + residual, 0.0, 1.0)


class DoubleConv(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1), nn.BatchNorm2d(out_ch), nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1), nn.BatchNorm2d(out_ch), nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class TinyUNet(nn.Module):
    def __init__(self, in_ch=3, base=16):
        super().__init__()
        self.e1 = DoubleConv(in_ch, base)
        self.e2 = DoubleConv(base, base*2)
        self.e3 = DoubleConv(base*2, base*4)
        self.pool = nn.MaxPool2d(2)
        self.b = DoubleConv(base*4, base*8)
        self.u3 = nn.ConvTranspose2d(base*8, base*4, 2, 2)
        self.d3 = DoubleConv(base*8, base*4)
        self.u2 = nn.ConvTranspose2d(base*4, base*2, 2, 2)
        self.d2 = DoubleConv(base*4, base*2)
        self.u1 = nn.ConvTranspose2d(base*2, base, 2, 2)
        self.d1 = DoubleConv(base*2, base)
        self.out = nn.Conv2d(base, 1, 1)

    def forward(self, x):
        e1 = self.e1(x)
        e2 = self.e2(self.pool(e1))
        e3 = self.e3(self.pool(e2))
        b = self.b(self.pool(e3))
        d3 = self.d3(torch.cat([self.u3(b), e3], dim=1))
        d2 = self.d2(torch.cat([self.u2(d3), e2], dim=1))
        d1 = self.d1(torch.cat([self.u1(d2), e1], dim=1))
        return self.out(d1)
