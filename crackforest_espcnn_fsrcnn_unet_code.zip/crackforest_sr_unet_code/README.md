# CrackForest: ESPCNN, FSRCNN, and Tiny U-Net

This repository provides a reproducible PyTorch workflow for:

1. Training patch-based residual ESPCNN and FSRCNN models with step-decay learning rates.
2. Training a lightweight U-Net for crack segmentation.
3. Evaluating whether super-resolution improves downstream crack segmentation.

## 1. Environment

Python 3.10 or 3.11 is recommended.

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

For a CUDA-enabled installation, install the appropriate PyTorch build from the official PyTorch instructions before installing the remaining requirements.

## 2. Dataset

Download or extract CrackForest so the folder layout is:

```text
data/CrackForest-dataset-master/
├── image/
│   ├── 001.jpg
│   └── ...
└── groundTruth/
    ├── 001.mat
    └── ...
```

From this package directory, the uploaded ZIP can be extracted with:

```bash
mkdir -p data
unzip CrackForest-dataset-master.zip -d data
```

If the dataset is elsewhere, change `data_root` in `configs/default.yaml`.

## 3. Reproducible split

All scripts use seed 42 and the same 70/15/15 train/validation/test split. The split is generated after sorting image names, then shuffling indices with Python's seeded random generator.

## 4. Train ESPCNN

```bash
python train_sr.py --model espcnn --config configs/default.yaml
```

Outputs:

```text
runs/espcnn/best.pt
runs/espcnn/history.csv
runs/espcnn/test_metrics.csv
runs/espcnn/summary.json
```

## 5. Train FSRCNN

```bash
python train_sr.py --model fsrcnn --config configs/default.yaml
```

Outputs are saved under `runs/fsrcnn/`.

## 6. Train Tiny U-Net

The U-Net is trained on the original resized high-resolution images and binary crack masks.

```bash
python train_unet.py --config configs/default.yaml
```

Outputs are saved under `runs/unet/`.

The default loss is:

```text
BCEWithLogitsLoss + soft Dice loss
```

The default U-Net step-decay schedule is:

- epochs 1–40: 1e-3
- epochs 41–70: 1e-4
- epochs 71–100: 1e-5

## 7. Evaluate downstream segmentation

After all three models are trained:

```bash
python evaluate_downstream.py \
  --config configs/default.yaml \
  --unet runs/unet/best.pt \
  --espcnn runs/espcnn/best.pt \
  --fsrcnn runs/fsrcnn/best.pt \
  --output runs/downstream_metrics.csv
```

This evaluates the same U-Net on:

- original resized HR images
- 4x-degraded then bicubic-reconstructed images
- ESPCNN-reconstructed images
- FSRCNN-reconstructed images

Reported metrics are precision, recall, Dice/F1, IoU, and pixel accuracy.

## 8. Generate super-resolved images

```bash
python generate_sr.py \
  --checkpoint runs/espcnn/best.pt \
  --input_dir data/CrackForest-dataset-master/image \
  --output_dir runs/espcnn/generated
```

Use `runs/fsrcnn/best.pt` to generate FSRCNN outputs.

## 9. Important methodological notes

- Physical crack width cannot be reported in millimeters without camera calibration or known ground sampling distance. Pixel width is acceptable for this dataset.
- Do not select a model using test metrics. The scripts save the checkpoint with minimum validation loss and evaluate the test set once.
- Because CrackForest contains only 118 images, repeat the experiment with several random seeds or cross-validation before making strong journal claims.
- Downstream Dice and IoU are more meaningful for engineering use than PSNR and SSIM alone.
- The current degradation is synthetic bicubic 4x downsampling. Real UAV blur, compression, illumination, and motion degradation should be tested separately for field deployment claims.

## 10. Configuration

Edit `configs/default.yaml` to change epochs, batch sizes, patch size, scale, learning-rate milestones, or output paths.

For a quick CPU smoke test:

```yaml
sr:
  epochs: 2
  patches_per_image: 2
unet:
  epochs: 2
```
