from __future__ import annotations

import argparse
import csv
from pathlib import Path

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm

from src.common import ensure_dir, get_device, load_config, save_json, set_seed
from src.data import SegmentationDataset, list_pairs, split_pairs
from src.metrics import metrics_from_counts, segmentation_counts
from src.models import TinyUNet


def dice_loss(logits, targets, eps=1e-6):
    p = torch.sigmoid(logits)
    num = 2 * (p * targets).sum(dim=(1,2,3)) + eps
    den = p.sum(dim=(1,2,3)) + targets.sum(dim=(1,2,3)) + eps
    return 1 - (num / den).mean()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    args = ap.parse_args()
    cfg = load_config(args.config); set_seed(cfg["seed"]); device = get_device()
    pairs = list_pairs(cfg["data_root"])
    tr, va, te = split_pairs(pairs, cfg["train_ratio"], cfg["val_ratio"], cfg["seed"])
    size = (cfg["hr_height"], cfg["hr_width"])
    train_loader = DataLoader(SegmentationDataset(tr, size, True), batch_size=cfg["unet"]["batch_size"], shuffle=True)
    val_loader = DataLoader(SegmentationDataset(va, size, False), batch_size=1)
    test_loader = DataLoader(SegmentationDataset(te, size, False), batch_size=1)
    out = ensure_dir(Path(cfg["output_root"]) / "unet")

    model = TinyUNet().to(device)
    bce = nn.BCEWithLogitsLoss()
    opt = torch.optim.Adam(model.parameters(), lr=cfg["unet"]["learning_rate"], weight_decay=cfg["unet"]["weight_decay"])
    sched = torch.optim.lr_scheduler.MultiStepLR(opt, milestones=cfg["unet"]["step_milestones"], gamma=cfg["unet"]["step_gamma"])
    best = float("inf"); patience = 0; hist = []
    for epoch in range(1, cfg["unet"]["epochs"] + 1):
        model.train(); total = 0.0
        for x, y, _ in tqdm(train_loader, desc=f"unet epoch {epoch}", leave=False):
            x, y = x.to(device), y.to(device)
            opt.zero_grad(set_to_none=True)
            z = model(x); loss = bce(z, y) + dice_loss(z, y)
            loss.backward(); opt.step(); total += loss.item() * x.size(0)
        train_loss = total / len(train_loader.dataset)
        model.eval(); val_loss = 0.0
        with torch.no_grad():
            for x, y, _ in val_loader:
                x, y = x.to(device), y.to(device); z = model(x)
                val_loss += (bce(z, y) + dice_loss(z, y)).item()
        val_loss /= len(val_loader)
        lr_now = opt.param_groups[0]["lr"]
        hist.append({"epoch": epoch, "train_loss": train_loss, "val_loss": val_loss, "lr": lr_now})
        if val_loss < best:
            best = val_loss; patience = 0
            torch.save({"model": model.state_dict(), "config": cfg, "epoch": epoch}, out / "best.pt")
        else:
            patience += 1
        sched.step()
        print(f"epoch={epoch:03d} train={train_loss:.6f} val={val_loss:.6f} lr={lr_now:.2e}")
        if patience >= cfg["unet"]["early_stopping_patience"]:
            print("Early stopping"); break

    with open(out / "history.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=hist[0].keys()); w.writeheader(); w.writerows(hist)
    ckpt = torch.load(out / "best.pt", map_location=device); model.load_state_dict(ckpt["model"]); model.eval()
    totals = [0,0,0,0]
    with torch.no_grad():
        for x,y,_ in test_loader:
            c = segmentation_counts(model(x.to(device)), y.to(device), cfg["unet"]["threshold"])
            totals = [a+b for a,b in zip(totals,c)]
    summary = metrics_from_counts(*totals)
    summary.update({"best_epoch": ckpt["epoch"], "best_val_loss": best, "parameters": sum(p.numel() for p in model.parameters())})
    save_json(summary, out / "summary.json"); print(summary)

if __name__ == "__main__":
    main()
