from __future__ import annotations

import argparse
import csv
from pathlib import Path

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm

from src.common import ensure_dir, get_device, load_config, save_json, set_seed
from src.data import SRFullDataset, SRPatchDataset, list_pairs, split_pairs
from src.metrics import sr_metrics
from src.models import ESPCNNResidual, FSRCNNResidual


def build_model(name, scale):
    if name == "espcnn":
        return ESPCNNResidual(scale=scale)
    if name == "fsrcnn":
        return FSRCNNResidual(scale=scale)
    raise ValueError(name)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--model", choices=["espcnn", "fsrcnn"], required=True)
    args = ap.parse_args()
    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    device = get_device()
    pairs = list_pairs(cfg["data_root"])
    train_pairs, val_pairs, test_pairs = split_pairs(pairs, cfg["train_ratio"], cfg["val_ratio"], cfg["seed"])

    out = ensure_dir(Path(cfg["output_root"]) / args.model)
    train_ds = SRPatchDataset(train_pairs, cfg["scale"], cfg["sr"]["hr_patch_size"], cfg["sr"]["patches_per_image"], True)
    train_loader = DataLoader(train_ds, batch_size=cfg["sr"]["batch_size"], shuffle=True, num_workers=cfg["num_workers"])
    val_loader = DataLoader(SRFullDataset(val_pairs, (cfg["hr_height"], cfg["hr_width"]), cfg["scale"]), batch_size=1)
    test_loader = DataLoader(SRFullDataset(test_pairs, (cfg["hr_height"], cfg["hr_width"]), cfg["scale"]), batch_size=1)

    model = build_model(args.model, cfg["scale"]).to(device)
    criterion = nn.L1Loss() if cfg["sr"]["loss"].lower() == "l1" else nn.MSELoss()
    opt = torch.optim.Adam(model.parameters(), lr=cfg["sr"]["learning_rate"], weight_decay=cfg["sr"]["weight_decay"])
    sched = torch.optim.lr_scheduler.MultiStepLR(opt, milestones=cfg["sr"]["step_milestones"], gamma=cfg["sr"]["step_gamma"])

    best = float("inf")
    history = []
    for epoch in range(1, cfg["sr"]["epochs"] + 1):
        model.train(); total = 0.0
        for lr, bic, hr in tqdm(train_loader, desc=f"{args.model} epoch {epoch}", leave=False):
            lr, bic, hr = lr.to(device), bic.to(device), hr.to(device)
            opt.zero_grad(set_to_none=True)
            pred = model(lr, bic)
            loss = criterion(pred, hr)
            loss.backward(); opt.step()
            total += loss.item() * lr.size(0)
        train_loss = total / len(train_loader.dataset)
        model.eval(); val_loss = 0.0
        with torch.no_grad():
            for lr, bic, hr, _ in val_loader:
                pred = model(lr.to(device), bic.to(device))
                val_loss += criterion(pred, hr.to(device)).item()
        val_loss /= len(val_loader)
        lr_now = opt.param_groups[0]["lr"]
        history.append({"epoch": epoch, "train_loss": train_loss, "val_loss": val_loss, "lr": lr_now})
        if val_loss < best:
            best = val_loss
            torch.save({"model": model.state_dict(), "config": cfg, "model_name": args.model, "epoch": epoch}, out / "best.pt")
        sched.step()
        print(f"epoch={epoch:03d} train={train_loss:.6f} val={val_loss:.6f} lr={lr_now:.2e}")

    with open(out / "history.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=history[0].keys()); w.writeheader(); w.writerows(history)

    ckpt = torch.load(out / "best.pt", map_location=device)
    model.load_state_dict(ckpt["model"]); model.eval()
    rows = []
    with torch.no_grad():
        for lr, bic, hr, stem in test_loader:
            lr, bic, hr = lr.to(device), bic.to(device), hr.to(device)
            pred = model(lr, bic)
            p_psnr, p_ssim = sr_metrics(pred[0], hr[0])
            b_psnr, b_ssim = sr_metrics(bic[0], hr[0])
            rows.append({"image": stem[0], "model_psnr": p_psnr, "model_ssim": p_ssim, "bicubic_psnr": b_psnr, "bicubic_ssim": b_ssim})
    with open(out / "test_metrics.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    summary = {k: sum(r[k] for r in rows)/len(rows) for k in ["model_psnr", "model_ssim", "bicubic_psnr", "bicubic_ssim"]}
    summary.update({"best_epoch": ckpt["epoch"], "best_val_loss": best, "parameters": sum(p.numel() for p in model.parameters())})
    save_json(summary, out / "summary.json")
    print(summary)

if __name__ == "__main__":
    main()
