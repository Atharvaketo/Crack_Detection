from __future__ import annotations

import argparse
import csv
from pathlib import Path

import torch
from PIL import Image
from torch.utils.data import DataLoader
from torchvision.transforms.functional import to_tensor

from src.common import get_device, load_config, save_json
from src.data import SegmentationDataset, list_pairs, split_pairs
from src.metrics import metrics_from_counts, segmentation_counts
from src.models import ESPCNNResidual, FSRCNNResidual, TinyUNet


def load_sr(path, device):
    ckpt = torch.load(path, map_location=device)
    name = ckpt["model_name"]; scale = ckpt["config"]["scale"]
    model = ESPCNNResidual(scale) if name == "espcnn" else FSRCNNResidual(scale)
    model.load_state_dict(ckpt["model"]); model.to(device).eval()
    return model, scale


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--unet", required=True)
    ap.add_argument("--espcnn", required=True)
    ap.add_argument("--fsrcnn", required=True)
    ap.add_argument("--output", default="runs/downstream_metrics.csv")
    args = ap.parse_args()
    cfg = load_config(args.config); device = get_device()
    pairs = list_pairs(cfg["data_root"]); _,_,test_pairs = split_pairs(pairs, cfg["train_ratio"], cfg["val_ratio"], cfg["seed"])
    size = (cfg["hr_height"], cfg["hr_width"])
    loader = DataLoader(SegmentationDataset(test_pairs, size, False), batch_size=1)
    uckpt = torch.load(args.unet, map_location=device); unet = TinyUNet().to(device); unet.load_state_dict(uckpt["model"]); unet.eval()
    espcnn, scale = load_sr(args.espcnn, device); fsrcnn, _ = load_sr(args.fsrcnn, device)
    totals = {k:[0,0,0,0] for k in ["original_hr","bicubic","espcnn","fsrcnn"]}
    with torch.no_grad():
        for hr, mask, _ in loader:
            hr, mask = hr.to(device), mask.to(device)
            lr = torch.nn.functional.interpolate(hr, scale_factor=1/scale, mode="bicubic", align_corners=False)
            bic = torch.nn.functional.interpolate(lr, size=hr.shape[-2:], mode="bicubic", align_corners=False)
            images = {"original_hr": hr, "bicubic": bic, "espcnn": espcnn(lr,bic), "fsrcnn": fsrcnn(lr,bic)}
            for key, x in images.items():
                c = segmentation_counts(unet(x), mask, cfg["unet"]["threshold"])
                totals[key] = [a+b for a,b in zip(totals[key],c)]
    rows = []
    for key,c in totals.items():
        row = {"input": key, **metrics_from_counts(*c)}; rows.append(row)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output,"w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    save_json(rows, Path(args.output).with_suffix(".json")); print(rows)

if __name__ == "__main__":
    main()
