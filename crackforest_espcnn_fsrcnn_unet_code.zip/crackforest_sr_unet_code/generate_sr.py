from __future__ import annotations

import argparse
from pathlib import Path

import torch
from PIL import Image
from torchvision.transforms.functional import to_pil_image, to_tensor

from src.common import ensure_dir, get_device
from src.models import ESPCNNResidual, FSRCNNResidual


def model_from_checkpoint(ckpt):
    name = ckpt["model_name"]
    scale = ckpt["config"]["scale"]
    model = ESPCNNResidual(scale) if name == "espcnn" else FSRCNNResidual(scale)
    model.load_state_dict(ckpt["model"])
    return model, name, scale


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--input_dir", required=True)
    ap.add_argument("--output_dir", required=True)
    ap.add_argument("--hr_height", type=int, default=128)
    ap.add_argument("--hr_width", type=int, default=128)
    args = ap.parse_args()
    device = get_device()
    ckpt = torch.load(args.checkpoint, map_location=device)
    model, name, scale = model_from_checkpoint(ckpt)
    model.to(device).eval()
    out = ensure_dir(args.output_dir)
    for path in sorted(Path(args.input_dir).glob("*.jpg")):
        hr = Image.open(path).convert("RGB").resize((args.hr_width, args.hr_height), Image.Resampling.BICUBIC)
        lr = hr.resize((args.hr_width//scale, args.hr_height//scale), Image.Resampling.BICUBIC)
        bic = lr.resize((args.hr_width, args.hr_height), Image.Resampling.BICUBIC)
        with torch.no_grad():
            pred = model(to_tensor(lr).unsqueeze(0).to(device), to_tensor(bic).unsqueeze(0).to(device))[0].cpu()
        to_pil_image(pred).save(out / f"{path.stem}.png")
    print(f"Saved {name} images to {out}")

if __name__ == "__main__":
    main()
